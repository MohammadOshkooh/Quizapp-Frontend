package com.example.quizella.presentation.main

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.quizella.presentation.util.Screen

@Composable
fun MainScreen(
    navHostController: NavController,
    onLogout: () -> Unit,
    viewModel: MainViewModel = hiltViewModel()
) {
    val points by viewModel.points

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Quizella") },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Logout"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "High Score: $points",
                style = MaterialTheme.typography.h5
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    navHostController.navigate(Screen.QuestionScreen.route)
                },
                modifier = Modifier.fillMaxWidth(0.7f)
            ) {
                Text("Start Quiz")
            }
        }
    }
}