package com.example.quizella.data.data_source.remote

import android.util.Log
import com.example.quizella.common.Constants
import com.example.quizella.data.data_source.remote.dto.AuthRequest
import com.example.quizella.data.data_source.remote.dto.LoginResponse
import com.example.quizella.data.data_source.remote.dto.QuestionResponse
import com.example.quizella.data.data_source.remote.dto.RegisterResponse
import io.ktor.client.HttpClient
import io.ktor.client.features.ClientRequestException
import io.ktor.client.features.RedirectResponseException
import io.ktor.client.features.ServerResponseException
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.url
import io.ktor.client.request.header
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders

class TriviaService(
    private val client: HttpClient
) {

    suspend fun getQuestions(): List<QuestionResponse> {
        return try {
            client.get {
                url(Constants.base_url)
            }
        } catch (e: RedirectResponseException) {
            Log.e("TriviaService", "Redirect: ${e.response.status.description}")
            emptyList()
        } catch (e: ClientRequestException) {
            Log.e("TriviaService", "Client error: ${e.response.status.description}")
            emptyList()
        } catch (e: ServerResponseException) {
            Log.e("TriviaService", "Server error: ${e.response.status.description}")
            emptyList()
        } catch (e: Exception) {
            Log.e("TriviaService", "Error: ${e.message}", e)
            emptyList()
        }
    }

    suspend fun register(
        username: String,
        password: String
    ): RegisterResponse {

        val request = AuthRequest(
            username = username,
            password = password
        )

        return client.post {
            url("${Constants.base_url}/auth/register")

            header(
                HttpHeaders.ContentType,
                ContentType.Application.Json
            )

            body = request
        }
    }

    suspend fun login(
        username: String,
        password: String
    ): LoginResponse {

        val request = AuthRequest(
            username = username,
            password = password
        )

        return client.post {
            url("${Constants.base_url}/auth/login")

            header(
                HttpHeaders.ContentType,
                ContentType.Application.Json
            )

            body = request
        }
    }
}