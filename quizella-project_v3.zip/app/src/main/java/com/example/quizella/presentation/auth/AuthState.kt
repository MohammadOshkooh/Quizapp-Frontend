package com.example.quizella.presentation.auth

/**
 * UI state for authentication screens.
 * Encapsulates all mutable data needed for login and registration UI.
 *
 * @property isLoading Indicates if a network or database operation is in progress.
 * @property isLoggedIn Flag indicating whether the user is currently authenticated.
 * @property username The current input value for username field.
 * @property password The current input value for password field.
 * @property confirmPassword The current input value for confirm password field (registration only).
 * @property error Error message to display, null if no error.
 * @property isRegisterMode Toggles between login and registration modes.
 */
data class AuthState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val username: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val error: String? = null,
    val isRegisterMode: Boolean = false
)