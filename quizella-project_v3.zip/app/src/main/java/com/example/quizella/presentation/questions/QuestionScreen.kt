/**
 *
 *	MIT License
 *
 *	Copyright (c) 2023 Gautam Hazarika
 *
 *	Permission is hereby granted, free of charge, to any person obtaining a copy
 *	of this software and associated documentation files (the "Software"), to deal
 *	in the Software without restriction, including without limitation the rights
 *	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *	copies of the Software, and to permit persons to whom the Software is
 *	furnished to do so, subject to the following conditions:
 *
 *	The above copyright notice and this permission notice shall be included in all
 *	copies or substantial portions of the Software.
 *
 *	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *	SOFTWARE.
 *
 **/

package com.example.quizella.presentation.questions

import android.annotation.SuppressLint
import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.quizella.R
import com.example.quizella.domain.model.Question

@Composable
fun QuestionScreen(
    viewModel: QuestionViewModel = hiltViewModel(),
    navHostController: NavHostController
) {
    val currQuestion by viewModel.currQuestionState
    val context = LocalContext.current
    val activity = (LocalContext.current as? Activity)

    BackHandler {
        viewModel.onEvent(QuestionEvent.OpenDialog)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = {
                viewModel.onEvent(QuestionEvent.OpenDialog)
            }) {
                Icon(
                    imageVector = Icons.Outlined.Logout,
                    contentDescription = stringResource(R.string.exit_app)
                )
            }
        }
        Spacer(modifier = Modifier.height(32.dp))

        if (viewModel.dialogState.value.state) {
            AlertDialog(
                onDismissRequest = {
                    viewModel.onEvent(QuestionEvent.CloseDialog)
                },
                buttons = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                activity?.finish()
                            },
                            colors = ButtonDefaults.buttonColors(
                                backgroundColor = Color(0xFF243D25)
                            )
                        ) {
                            Text(
                                text = "Yes!",
                                color = Color.White
                            )
                        }
                    }
                },
                text = {
                    Text(text = viewModel.dialogState.value.text)
                }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Get current question safely
            val currentQuestion = currQuestion.currQuestion

            if (currentQuestion != null && currentQuestion.question.isNotEmpty()) {
                QuestionCard(
                    questionNo = currQuestion.questionNo ?: 1,
                    question = currentQuestion,
                    isEnabled = currQuestion.isEnabled,
                    currAns = currQuestion.currAns,
                    onClick = {
                        viewModel.onEvent(QuestionEvent.ChangeAnswer(it))
                    }
                )
                Button(
                    modifier = Modifier.width(150.dp),
                    onClick = {
                        if (currQuestion.currAns.isNotEmpty()) {
                            viewModel.onEvent(
                                QuestionEvent.NextQuestion(navHostController)
                            )
                        } else {
                            Toast.makeText(
                                context,
                                context.getString(R.string.please_select_an_answer),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color(0xFFAF0171).copy(0.7f)
                    )
                ) {
                    Text(
                        text = if (currQuestion.isEnabled) {
                            stringResource(R.string.submit)
                        } else {
                            stringResource(R.string.next)
                        }
                    )
                }
            } else {
                // Show loading state
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(450.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        color = Color.White
                    )
                }
            }
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@Composable
fun QuestionCard(
    questionNo: Int,
    question: Question,
    isEnabled: Boolean,
    currAns: String,
    onClick: (String) -> Unit
) {
    Column {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFFE80F88).copy(0.75f))
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Q$questionNo. " + question.question, fontSize = 16.sp)
        }
        LazyColumn(
            contentPadding = PaddingValues(0.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(question.answers) { answer ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(
                            BorderStroke(
                                if (!isEnabled && (answer == question.correctAnswer)) {
                                    3.dp
                                } else {
                                    0.dp
                                }, Color(0xFF058011)
                            ), RoundedCornerShape(16.dp)
                        )
                        .background(
                            if (!isEnabled && (answer == question.correctAnswer)) {
                                Color(0xFF1AC536)
                            } else {
                                Color(0xFFAF0171)
                            }
                        )
                        .clickable(enabled = isEnabled) {
                            onClick(answer)
                        }
                        .padding(8.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp, 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = answer)
                        RadioButton(
                            selected = currAns == answer,
                            onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = if (!isEnabled) {
                                    Color.Black
                                } else {
                                    Color.Cyan
                                }
                            )
                        )
                    }
                }
            }
        }
    }
}