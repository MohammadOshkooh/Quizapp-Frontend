package com.example.quizella.data.data_source.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class AuthRequest(
    val username: String,
    val password: String
)

@Serializable
data class RegisterResponse(
    val id: Int,
    val username: String,
    val email: String? = null,
    val created_at: String
)

@Serializable
data class LoginResponse(
    val access_token: String,
    val token_type: String
)