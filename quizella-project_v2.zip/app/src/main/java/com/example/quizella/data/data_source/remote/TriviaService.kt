package com.example.quizella.data.data_source.remote

import android.util.Log
import com.example.quizella.common.Constants
import com.example.quizella.data.data_source.remote.dto.AuthRequest
import com.example.quizella.data.data_source.remote.dto.LoginResponse
import com.example.quizella.data.data_source.remote.dto.QuestionResponse
import com.example.quizella.data.data_source.remote.dto.RegisterResponse
import io.ktor.client.HttpClient
import io.ktor.client.features.ClientRequestException
import io.ktor.client.features.RedirectResponseException
import io.ktor.client.features.ServerResponseException
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.url
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode

class TriviaService(
    private val client: HttpClient
) {

    suspend fun getQuestions(): List<QuestionResponse> {
        return try {
            client.get {
                url(Constants.base_url)
            }
        } catch (e: RedirectResponseException) {
            Log.d("TriviaService", "3xx error: ${e.response.status.description}")
            emptyList()
        } catch (e: ClientRequestException) {
            Log.d("TriviaService", "4xx error: ${e.response.status.description}")
            emptyList()
        } catch (e: ServerResponseException) {
            Log.d("TriviaService", "5xx error: ${e.response.status.description}")
            emptyList()
        } catch (e: Exception) {
            Log.e("TriviaService", "Error getting questions", e)
            emptyList()
        }
    }

    suspend fun register(
        username: String,
        password: String
    ): Result<RegisterResponse> {
        return try {

            val response: RegisterResponse = client.post {
                url("${Constants.API_BASE_URL}/api/auth/register")

                header(
                    HttpHeaders.ContentType,
                    ContentType.Application.Json.toString()
                )

                this.body = AuthRequest(
                    username = username,
                    password = password
                )
            }

            Result.success(response)

        } catch (e: ClientRequestException) {

            val message = when (e.response.status) {
                HttpStatusCode.BadRequest ->
                    "Username already exists"

                else ->
                    "Registration failed: ${e.response.status.description}"
            }

            Log.e("TriviaService", message, e)

            Result.failure(Exception(message))

        } catch (e: ServerResponseException) {

            Log.e(
                "TriviaService",
                "Server error during registration",
                e
            )

            Result.failure(
                Exception(
                    "Server error: ${e.response.status.description}"
                )
            )

        } catch (e: Exception) {

            Log.e(
                "TriviaService",
                "Error during registration",
                e
            )

            Result.failure(e)
        }
    }

    suspend fun login(
        username: String,
        password: String
    ): Result<LoginResponse> {
        return try {

            val response: LoginResponse = client.post {
                url("${Constants.API_BASE_URL}/api/auth/login")

                header(
                    HttpHeaders.ContentType,
                    ContentType.Application.Json.toString()
                )

                this.body = AuthRequest(
                    username = username,
                    password = password
                )
            }

            Result.success(response)

        } catch (e: ClientRequestException) {

            val message = when (e.response.status) {
                HttpStatusCode.Unauthorized ->
                    "Invalid username or password"

                else ->
                    "Login failed: ${e.response.status.description}"
            }

            Log.e("TriviaService", message, e)

            Result.failure(Exception(message))

        } catch (e: ServerResponseException) {

            Log.e(
                "TriviaService",
                "Server error during login",
                e
            )

            Result.failure(
                Exception(
                    "Server error: ${e.response.status.description}"
                )
            )

        } catch (e: Exception) {

            Log.e(
                "TriviaService",
                "Error during login",
                e
            )

            Result.failure(e)
        }
    }
}