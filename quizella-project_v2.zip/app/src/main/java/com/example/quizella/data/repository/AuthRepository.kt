package com.example.quizella.domain.repository

import com.example.quizella.domain.model.User
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface for authentication operations.
 *
 * Authentication itself is handled by the backend API.
 * DataStore is only used to persist the local login session.
 */
interface AuthRepository {

    /**
     * Registers a new user through the backend API.
     */
    suspend fun register(
        username: String,
        password: String
    ): Result<User>

    /**
     * Authenticates the user through the backend API.
     */
    suspend fun login(
        username: String,
        password: String
    ): Result<User>

    /**
     * Saves the authenticated session locally.
     *
     * The actual user account remains stored on the backend.
     */
    suspend fun saveLoginState(
        isLoggedIn: Boolean,
        username: String = "",
        accessToken: String = ""
    )

    /**
     * Returns the current local login state.
     */
    fun getLoginState(): Flow<Pair<Boolean, String>>

    /**
     * Returns the currently stored JWT access token.
     */
    suspend fun getAccessToken(): String?

    /**
     * Clears the local authentication session.
     */
    suspend fun logout()
}