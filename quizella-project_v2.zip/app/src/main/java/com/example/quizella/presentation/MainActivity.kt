package com.example.quizella.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.quizella.presentation.auth.AuthViewModel
import com.example.quizella.presentation.auth.LoginScreen
import com.example.quizella.presentation.auth.RegisterScreen
import com.example.quizella.presentation.finish.FinishScreen
import com.example.quizella.presentation.main.MainScreen
import com.example.quizella.presentation.questions.QuestionScreen
import com.example.quizella.presentation.util.Screen
import com.example.quizella.ui.theme.QuizellaTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuizellaTheme {
                val authViewModel: AuthViewModel = hiltViewModel()
                val authState by authViewModel.state.collectAsState()

                val navController = rememberNavController()

                val startDestination = if (authState.isLoggedIn) {
                    Screen.MainScreen.route
                } else {
                    Screen.LoginScreen.route
                }

                NavHost(
                    navController = navController,
                    startDestination = startDestination
                ) {
                    composable(Screen.LoginScreen.route) {
                        LoginScreen(
                            navController = navController,
                            onLoginSuccess = {
                                navController.navigate(Screen.MainScreen.route) {
                                    popUpTo(Screen.LoginScreen.route) { inclusive = true }
                                }
                            }
                        )
                    }
                    composable(Screen.RegisterScreen.route) {
                        RegisterScreen(
                            navController = navController,
                            onRegisterSuccess = {
                                navController.navigate(Screen.MainScreen.route) {
                                    popUpTo(Screen.RegisterScreen.route) { inclusive = true }
                                }
                            }
                        )
                    }
                    composable(Screen.MainScreen.route) {
                        MainScreen(
                            navHostController = navController,
                            onLogout = {
                                authViewModel.logout()
                                navController.navigate(Screen.LoginScreen.route) {
                                    popUpTo(Screen.MainScreen.route) { inclusive = true }
                                }
                            }
                        )
                    }
                    composable(Screen.QuestionScreen.route) {
                        QuestionScreen(navHostController = navController)
                    }
                    composable(Screen.FinishScreen.route) {
                        FinishScreen(navHostController = navController)
                    }
                }
            }
        }
    }
}