package com.example.quizella.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.quizella.data.data_source.remote.TriviaService
import com.example.quizella.domain.model.User
import com.example.quizella.domain.repository.AuthRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

/**
 * Implementation of AuthRepository.
 *
 * User registration and authentication are handled by the backend API.
 * DataStore is used only for persisting the local authentication session
 * and JWT access token.
 */
private val Context.dataStore by preferencesDataStore("auth_prefs")

class AuthRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val triviaService: TriviaService
) : AuthRepository {

    companion object {

        private val IS_LOGGED_IN =
            booleanPreferencesKey("is_logged_in")

        private val USERNAME =
            stringPreferencesKey("username")

        private val ACCESS_TOKEN =
            stringPreferencesKey("access_token")
    }

    /**
     * Registers a new user through the backend API.
     *
     * The backend is responsible for:
     * - Creating the user
     * - Hashing the password with bcrypt
     * - Saving the user in the backend database
     */
    override suspend fun register(
        username: String,
        password: String
    ): Result<User> {

        return triviaService
            .register(username, password)
            .map { response ->
                User(
                    id = response.id,
                    username = response.username,
                    passwordHash = ""
                )
            }
    }

    /**
     * Authenticates a user through the backend API.
     *
     * The backend verifies the password and returns a JWT.
     */
    override suspend fun login(
        username: String,
        password: String
    ): Result<User> {

        return triviaService
            .login(username, password)
            .map { response ->

                saveLoginState(
                    isLoggedIn = true,
                    username = username,
                    accessToken = response.access_token
                )

                User(
                    username = username,
                    passwordHash = ""
                )
            }
    }

    /**
     * Saves the local authentication session.
     *
     * No user or password is stored in Room.
     */
    override suspend fun saveLoginState(
        isLoggedIn: Boolean,
        username: String,
        accessToken: String
    ) {
        context.dataStore.edit { prefs ->

            prefs[IS_LOGGED_IN] = isLoggedIn

            if (isLoggedIn) {
                prefs[USERNAME] = username
                prefs[ACCESS_TOKEN] = accessToken
            } else {
                prefs.remove(USERNAME)
                prefs.remove(ACCESS_TOKEN)
            }
        }
    }

    /**
     * Observes the current local login state.
     */
    override fun getLoginState(): Flow<Pair<Boolean, String>> {

        return context.dataStore.data.map { prefs ->

            val isLoggedIn =
                prefs[IS_LOGGED_IN] ?: false

            val username =
                prefs[USERNAME] ?: ""

            isLoggedIn to username
        }
    }

    /**
     * Returns the stored JWT access token.
     */
    override suspend fun getAccessToken(): String? {

        var token: String? = null

        context.dataStore.data.collect { prefs ->
            token = prefs[ACCESS_TOKEN]
            return@collect
        }

        return token
    }

    /**
     * Clears the local authentication session.
     *
     * The backend user is not deleted.
     */
    override suspend fun logout() {
        saveLoginState(false)
    }
}