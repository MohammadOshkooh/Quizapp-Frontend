/**
 *
 * MIT License
 *
 * Copyright (c) 2023 Gautam Hazarika
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software.
 *
 **/

package com.example.quizella.common

object Constants {

    const val API_BASE_URL = "http://10.0.2.2:8000"

    const val base_url =
        "$API_BASE_URL/api/questions/?limit=10&category=science%2Chistory"
}

//object Constants {
//    const val base_url = "http://10.0.2.2:8000/api/questions/?limit=10&category=science%2Chistory"
//
////    const val base_url = "http://10.0.2.2:8000/api/questions?limit=10&categories=science,history"
////    const val base_url = "http://127.0.0.1:8000/api/questions/?limit=10"
////    const val base_url = "https://the-trivia-api.com/api/questions?limit=10&categories=science,history"
//}
